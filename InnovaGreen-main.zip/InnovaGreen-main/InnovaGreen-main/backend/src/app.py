import os.path

from flask import Flask
import graphene
from flask_talisman import Talisman
from flask_graphql import GraphQLView
from flask_cors import CORS
import secrets
from pymongo import MongoClient
from bson import ObjectId
from itertools import groupby
from datetime import datetime

# MongoDB Atlas connection string
conn_string = "mongodb+srv://admin:admin@cluster0.aznm8vc.mongodb.net/?retryWrites=true&w=majority"

# Connect to MongoDB Atlas
client = MongoClient(conn_string)

# Specify the database
db = client['dataBase']
bankAccounts_collection = db['bankAccounts']
orders_collection = db['orders']
products_collection = db['products']
users_collection = db['users']

fee = 0.2 # 20% fee which innovagreen holds in from every sold product

def generate_secure_token():
    token = secrets.token_urlsafe(nbytes=16)
    return token


def getUser(email, password):
    user = users_collection.find_one({"email": email, "password": password})
    return user

# define classes for user defined types
class ProductType(graphene.ObjectType):
    produktID = graphene.String()
    bezeichnung = graphene.String()
    verfallsdatum = graphene.String()
    standort = graphene.String()
    preis = graphene.Float()
    lieferant = graphene.String()

class UserType(graphene.ObjectType):
    id = graphene.ID()
    name = graphene.String()
    email = graphene.String()
    role = graphene.String()

class CartItemType(graphene.InputObjectType):
    produktID = graphene.String()
    bezeichnung = graphene.String()
    verfallsdatum = graphene.String()
    standort = graphene.String()
    preis = graphene.Float()
    lieferant = graphene.String()

class CartItemOutputType(graphene.ObjectType):
    produktID = graphene.String()
    bezeichnung = graphene.String()
    verfallsdatum = graphene.String()
    standort = graphene.String()
    preis = graphene.Float()
    lieferant = graphene.String()


class OrderType(graphene.ObjectType):
    orderID = graphene.String()
    cartItems = graphene.List(CartItemOutputType)
    totalPrice = graphene.Float()
    orderDate = graphene.String()
    email = graphene.String()


class Query(graphene.ObjectType):
    search_products = graphene.List(ProductType, keyword=graphene.String(default_value=""), location=graphene.String(default_value=""), min_price=graphene.Float(default_value=0), max_price=graphene.Float(default_value=10000))

    all_users = graphene.List(UserType)

    all_products = graphene.List(ProductType)

    def resolve_all_users(self, info):
        query = {"role": {"$in": ["Kunde", "Lieferant"]}}
        users = users_collection.find(query)
        return [UserType(id=user['_id'], name=user['name'], email=user['email'], role=user['role']) for user in users]

    def resolve_all_products(self, info):
        # Nur Admins dürfen alle Benutzer abfragen
        # Hier sollten Sie überprüfen, ob der anfragende Benutzer ein Admin ist
        products = products_collection.find()
        return [ProductType(produktID=product['_id'], lieferant=product['lieferant'], bezeichnung=product['bezeichnung'], verfallsdatum=product['verfallsdatum'], standort=product['standort'], preis=product['preis']) for product in products]

    def resolve_search_products(self, info, keyword, location, min_price, max_price):
        query = {}
        if keyword:
            query['bezeichnung'] = {'$regex': keyword, '$options': 'i'}
        if location:
            query['standort'] = {'$regex': location, '$options': 'i'}
        query['preis'] = {'$gte': min_price, '$lte': max_price}

        products = products_collection.find(query)
        return [ProductType(produktID=p['_id'], lieferant=p['lieferant'], bezeichnung=p['bezeichnung'], verfallsdatum=p['verfallsdatum'], standort=p['standort'], preis=p['preis']) for p in products]


    my_products = graphene.List(ProductType, lieferantEmail=graphene.String(required=True))

    def resolve_my_products(self, info, lieferantEmail):
        products = products_collection.find({"lieferant": lieferantEmail})
        return [ProductType(produktID=p['_id'], lieferant=p['lieferant'], bezeichnung=p['bezeichnung'], verfallsdatum=p['verfallsdatum'], standort=p['standort'], preis=p['preis']) for p in products]


    my_orders = graphene.List(OrderType, email=graphene.String(required=True))
    def resolve_my_orders(self, info, email):
        orders = orders_collection.find({"email": email})
        return [OrderType(orderID=o['_id'], cartItems=o['cartItems'], totalPrice=o['totalPrice'], orderDate=o['orderDate'], email=o['email']) for o in orders]


def money_transfer_customer(cardNumber, expiryDate, cvv, cardHolder, totalPrice):
    a = bankAccounts_collection.update_one({"cardNumber": cardNumber, "expiryDate": expiryDate, "cvv": cvv, "cardHolder": cardHolder}, {"$inc": {"balance": -totalPrice}})
    # Geld zum InnovaGreen-Konto hinzufügen
    b = bankAccounts_collection.update_one({"cardHolder": "InnovaGreen"}, {"$inc": {"balance": totalPrice}})
    return a.modified_count == 1 and b.modified_count == 1

def money_transfer_supplier(supplier, amount):
    a = bankAccounts_collection.update_one({"email": supplier}, {"$inc": {"balance": amount}})
    b = bankAccounts_collection.update_one({"cardHolder": "InnovaGreen"}, {"$inc": {"balance": -amount}})
    return a.modified_count == 1 and b.modified_count == 1


def remove_products(cartItems):
    productIDs = [item['produktID'] for item in cartItems]
    print(productIDs)
    for id in productIDs:
        print(products_collection.delete_one({'_id': ObjectId(id)}))


def save_order(email, cardNumber, cartItems, totalPrice):
    order = {
        'cartItems': cartItems,
        'totalPrice': totalPrice,
        'orderDate': datetime.now().strftime("%d.%m.%Y %H:%M"),
        'email': email,
        'cardNumber': cardNumber
    }
    orders_collection.insert_one(order)


class CheckoutMutation(graphene.Mutation):
    class Arguments:
        cardNumber = graphene.String(required=True)
        expiryDate = graphene.String(required=True)
        cvv = graphene.String(required=True)
        cardHolder = graphene.String(required=True)
        totalPrice = graphene.Float(required=True)
        cartItems = graphene.List(CartItemType)
        email = graphene.String(required=True)

    ok = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, cardNumber, expiryDate, cvv, cardHolder, totalPrice, cartItems, email):
        # validate card data
        if bankAccounts_collection.find_one({'cardNumber': cardNumber, 'expiryDate': expiryDate, 'cvv': cvv, 'cardHolder': cardHolder}) is None:
            return CheckoutMutation(ok=False, message="Invalid card data.")

        # money transfer from customer bank account to innovagreen bank account
        customer_to_innovagreen = money_transfer_customer(cardNumber, expiryDate, cvv, cardHolder, totalPrice)

        # money transfer from innovagreen bank account to supplier bank account, minus a fee of 20%
        innovagreen_to_suppliers = True
        sorted_cart_items = sorted(cartItems, key=lambda x: x['lieferant'])
        grouped_cart_items = {key: list(group) for key, group in groupby(sorted_cart_items, key=lambda x: x['lieferant'])}
        for supplier, items in grouped_cart_items.items():
            supplier_total = 0
            for item in items:
                supplier_total += item['preis']
            innovagreen_to_suppliers = innovagreen_to_suppliers and money_transfer_supplier(supplier, supplier_total * (1-fee))

        remove_products(cartItems)
        save_order(email, cardNumber, cartItems, totalPrice)

        if customer_to_innovagreen and innovagreen_to_suppliers:
            return CheckoutMutation(ok=True, message="Transaction successful")
        else:
            return CheckoutMutation(ok=False, message="Transaction failed")

class NewFoodMutation(graphene.Mutation):
    class Arguments:
        bezeichnung = graphene.String(required=True)
        standort = graphene.String(required=True)
        verfallsdatum = graphene.String(required=True)
        preis = graphene.Float(required=True)
        lieferant = graphene.String(required=True)

    ok = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, bezeichnung, standort, verfallsdatum, preis, lieferant):
        produkt = {
            "bezeichnung": bezeichnung,
            "standort": standort,
            "verfallsdatum": verfallsdatum,
            "preis": preis,
            "lieferant": lieferant
        }
        try:
            products_collection.insert_one(produkt).inserted_id
            return NewFoodMutation(ok=True, message="Produkt erfolgreich gespeichert.")
        except Exception as e:
            return NewFoodMutation(ok=False, message=f"Fehler beim Speichern des Produkts: {e}")


class RegistrationMutation(graphene.Mutation):
    class Arguments:
        name = graphene.String(required=True)
        email = graphene.String(required=True)
        address = graphene.String(required=True)
        password = graphene.String(required=True)
        role = graphene.String(required=True)

    ok = graphene.Boolean()
    message = graphene.String()
    authToken = graphene.String()

    def mutate(self, info, name, email, address, password, role):
        if users_collection.find_one({"email": email}):
            print("exists")
            return RegistrationMutation(ok=False, message="Email address already exists.")

        users_collection.insert_one({"name": name, "email": email, "address": address, "password": password, "role": role})
        print("not exists")
        return RegistrationMutation(ok=True, authToken=generate_secure_token(), message="User registered successfully.")


class LoginMutation(graphene.Mutation):
    class Arguments:
        email = graphene.String(required=True)
        password = graphene.String(required=True)

    ok = graphene.Boolean()
    message = graphene.String()
    role = graphene.String()
    authToken = graphene.String()

    def mutate(self, info, email, password):
        user = getUser(email, password)
        if user is not None:
            print(user.get("role"))
            return LoginMutation(ok=True, authToken=generate_secure_token(), message="Login successful", role=user.get("role"))
        else:
            return LoginMutation(ok=False, message="Invalid credentials.")

class RemoveProductMutation(graphene.Mutation):
    class Arguments:
        produktID = graphene.String(required=True)

    ok = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, produktID):
        try:
            result = products_collection.delete_one({"_id": ObjectId(produktID)})
            if result.deleted_count > 0:
                return RemoveProductMutation(ok=True, message="Produkt erfolgreich gelöscht.")
            else:
                return RemoveProductMutation(ok=False, message="Produkt nicht gefunden.")
        except Exception as e:
            return RemoveProductMutation(ok=False, message=f"Fehler beim Löschen des Produkts: {e}")

class RemoveUserMutation(graphene.Mutation):
    class Arguments:
        userID = graphene.String(required=True)

    ok = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, userID):
        try:
            result = users_collection.delete_one({"_id": ObjectId(userID)})
            if result.deleted_count > 0:
                return RemoveUserMutation(ok=True, message="User erfolgreich gelöscht.")
            else:
                return RemoveUserMutation(ok=False, message="User nicht gefunden.")
        except Exception as e:
            return RemoveUserMutation(ok=False, message=f"Fehler beim Löschen des Users: {e}")


class UpdateProductMutation(graphene.Mutation):
    class Arguments:
        produktID = graphene.String(required=True)
        bezeichnung = graphene.String()
        verfallsdatum = graphene.String()
        standort = graphene.String()
        preis = graphene.Float()

    ok = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, produktID, bezeichnung=None, verfallsdatum=None, standort=None, preis=None):
        update_values = {k: v for k, v in {
            "bezeichnung": bezeichnung,
            "verfallsdatum": verfallsdatum,
            "standort": standort,
            "preis": preis
        }.items() if v is not None}

        result = products_collection.update_one({"_id": ObjectId(produktID)}, {"$set": update_values})

        if result.matched_count > 0:
            return UpdateProductMutation(ok=True, message="Produkt erfolgreich aktualisiert.")
        else:
            return UpdateProductMutation(ok=False, message="Produkt nicht gefunden.")

class UpdateUserMutation(graphene.Mutation):
    class Arguments:
        id = graphene.String(required=True)
        name = graphene.String()
        email = graphene.String()
        role = graphene.String()

    ok = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, id, name=None, email=None, role=None):
        update_values = {k: v for k, v in {
            "name": name,
            "email": email,
            "role": role,
        }.items() if v is not None}

        result = users_collection.update_one({"_id": ObjectId(id)}, {"$set": update_values})

        if result.matched_count > 0:
            return UpdateUserMutation(ok=True, message="User erfolgreich aktualisiert.")
        else:
            return UpdateUserMutation(ok=False, message="User nicht gefunden.")

class CancelOrderMutation(graphene.Mutation):
    class Arguments:
        orderID = graphene.String(required=True)

    ok = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, orderID):
        order = orders_collection.find_one({'_id': ObjectId(orderID)})

        # re-inserte products into products_collection
        for item in order['cartItems']:
            product = {
                '_id': ObjectId(item['produktID']),
                'bezeichnung': item['bezeichnung'],
                'verfallsdatum': item['verfallsdatum'],
                'standort': item['standort'],
                'preis': item['preis'],
                'lieferant': item['lieferant']
            }
            products_collection.insert_one(product)

        # delete order
        orders_collection.delete_one({'_id': ObjectId(orderID)})

        # transfer money from innovagreen bank account back to the customers bank account
        success = True
        success = success and bankAccounts_collection.update_one({"cardNumber": order['cardNumber']}, {"$inc": {"balance": order['totalPrice']}}).modified_count == 1
        success = success and bankAccounts_collection.update_one({"cardHolder": "InnovaGreen"}, {"$inc": {"balance": -order['totalPrice']}}).modified_count == 1

        # transfer money from suppliers back to innovagreen
        sorted_items = sorted(order['cartItems'], key=lambda x: x['lieferant'])
        grouped_items = {key: list(group) for key, group in groupby(sorted_items, key=lambda x: x['lieferant'])}

        for supplier, items in grouped_items.items():
            supplier_total = 0
            for item in items:
                supplier_total += item['preis']
            success = success and bankAccounts_collection.update_one({"email": supplier}, {"$inc": {"balance": -supplier_total*(1-fee)}}).modified_count == 1
            success = success and bankAccounts_collection.update_one({"cardHolder": "InnovaGreen"}, {"$inc": {"balance": supplier_total*(1-fee)}}).modified_count == 1

        if success:
            return CancelOrderMutation(ok=True, message="Bestellung erfolgreich storniert.")
        else:
            return CancelOrderMutation(ok=False, message="Bestellung stornieren Fehlgeschlagen.")


class Mutation(graphene.ObjectType):
    login = LoginMutation.Field()
    register = RegistrationMutation.Field()
    new_food = NewFoodMutation.Field()
    remove_product = RemoveProductMutation.Field()
    remove_user = RemoveUserMutation.Field()
    update_product = UpdateProductMutation.Field()
    update_user = UpdateUserMutation.Field()
    checkout = CheckoutMutation.Field()
    cancelOrder = CancelOrderMutation.Field()


schema = graphene.Schema(query=Query, mutation=Mutation)

# Flask app setup
app = Flask(__name__)
# Talisman(app)
CORS(app, resources={r"/graphql/*": {"origins": "*"}})
app.add_url_rule('/graphql', view_func=GraphQLView.as_view('graphql', schema=schema, graphiql=True))

if __name__ == '__main__':
#    app_dir = os.path.abspath(os.path.dirname(__file__))

#    cert_path = os.path.join(app_dir, '../cert.pem')
#    key_path = os.path.join(app_dir, '../key.pem')

    app.run(host='0.0.0.0', port=5002, debug=True) #, ssl_context=(cert_path, key_path))
