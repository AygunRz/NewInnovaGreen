from pymongo import MongoClient

# Direct specification of the MongoDB connection string
mongo_conn_string = "mongodb+srv://admin:admin@cluster0.aznm8vc.mongodb.net/?retryWrites=true&w=majority"

# Establish a connection to MongoDB Atlas
client = MongoClient(mongo_conn_string)

# Specify the database
db = client['dataBase']

# Delete the collection
db['bankAccounts'].drop()
db['orders'].drop()
db['products'].drop()
db['users'].drop()

# Define collections
bankAccounts_collection = db['bankAccounts']
orders_collection = db['orders']
products_collection = db['products']
users_collection = db['users']

# init some bank accounts
account_data = {
    "cardNumber": "123456",
    "expiryDate": "12/24",
    "cvv": "123",
    "cardHolder": "Liam Austrian",
    "email": "austrian@gmail.com",
    "balance": 4000
}
bankAccounts_collection.insert_one(account_data)

account_data = {
    "cardNumber": "112233",
    "expiryDate": "12/25",
    "cvv": "321",
    "cardHolder": "Leo Fuchs",
    "email": "fuchs@gmail.com",
    "balance": 500
}
bankAccounts_collection.insert_one(account_data)

account_data = {
    "cardNumber": "000000",
    "expiryDate": "12/24",
    "cvv": "000",
    "cardHolder": "Max Mustermann",
    "email": "mustermann@gmail.com",
    "balance": 10000
}
bankAccounts_collection.insert_one(account_data)

account_data = {
    "cardNumber": "45555",
    "expiryDate": "12/24",
    "cvv": "123",
    "cardHolder": "SPAR Österreichische Warenhandels-AG",
    "email": "sortiment@spar.at",
    "balance": 60000
}
bankAccounts_collection.insert_one(account_data)

account_data = {
    "cardNumber": "566666",
    "expiryDate": "12/24",
    "cvv": "123",
    "cardHolder": "HOFER Kommanditgesellschaft",
    "email": "produkte@hofer.at",
    "balance": 60000
}
bankAccounts_collection.insert_one(account_data)

account_data = {
    "cardNumber": "9999999999999999",
    "expiryDate": "12/24",
    "cvv": "123",
    "cardHolder": "InnovaGreen",
    "email": "admin@innovagreen.com",
    "balance": 1000
}
bankAccounts_collection.insert_one(account_data)


# init some users
user_data = {
    "name": "Liam Austrian",
    "email": "austrian@gmail.com",
    "address": "Rennweg 20, 1030 Wien",
    "password": "liam",
    "role": "Kunde"
}
users_collection.insert_one(user_data)

user_data = {
    "name": "Leo Fuchs",
    "email": "fuchs@gmail.com",
    "address": "Rennweg 21, 1030 Wien",
    "password": "leo",
    "role": "Kunde"
}
users_collection.insert_one(user_data)

user_data = {
    "name": "Max Mustermann",
    "email": "mustermann@gmail.com",
    "address": "Stephansplatz 17, 1010 Wien",
    "password": "max",
    "role": "Kunde"
}
users_collection.insert_one(user_data)

user_data = {
    "name": "SPAR Österreichische Warenhandels-AG",
    "email": "sortiment@spar.at",
    "address": "Europastraße 3, 5015 Salzburg, Österreich",
    "password": "spar",
    "role": "Lieferant"
}
id_spar = users_collection.insert_one(user_data).inserted_id

user_data = {
    "name": "HOFER Kommanditgesellschaft",
    "email": "produkte@hofer.at",
    "address": "Hoferstraße 1, A-4642 Sattledt",
    "password": "hofer",
    "role": "Lieferant"
}
id_hofer = users_collection.insert_one(user_data).inserted_id

user_data = {
    "name": "admin",
    "email": "admin@innovagreen.com",
    "address": "Adminstraße 1, 1010 Wien",
    "password": "admin",
    "role": "Admin"
}
users_collection.insert_one(user_data)

# insert some products
product_data = {
    "bezeichnung": "Wurstwaren",
    "verfallsdatum": "31.01.2024",
    "standort": "Spar - Rennweg 46/50, 1030 Wien",
    "preis": 4.20,
    "lieferant": "sortiment@spar.at"
}
products_collection.insert_one(product_data)

product_data = {
    "bezeichnung": "Hühnerfleisch",
    "verfallsdatum": "31.01.2024",
    "standort": "Spar - Rennweg 46/50, 1030 Wien",
    "preis": 7.20,
    "lieferant": "sortiment@spar.at"
}
products_collection.insert_one(product_data)

product_data = {
    "bezeichnung": "Bio Orangen",
    "verfallsdatum": "31.01.2024",
    "standort": "Spar - Rennweg 46/50, 1030 Wien",
    "preis": 3.10,
    "lieferant": "sortiment@spar.at"
}
products_collection.insert_one(product_data)

product_data = {
    "bezeichnung": "Bio Vollmilch",
    "verfallsdatum": "31.01.2024",
    "standort": "Spar - Rennweg 46/50, 1030 Wien",
    "preis": 0.90,
    "lieferant": "sortiment@spar.at"
}
products_collection.insert_one(product_data)

product_data = {
    "bezeichnung": "Bio Joghurt",
    "verfallsdatum": "01.02.2024",
    "standort": "Hofer - Lerchenfelder Str. 14, 1080 Wien",
    "preis": 0.80,
    "lieferant": "produkte@hofer.at"
}
products_collection.insert_one(product_data)

product_data = {
    "bezeichnung": "Kekse",
    "verfallsdatum": "01.02.2024",
    "standort": "Hofer - Lerchenfelder Str. 14, 1080 Wien",
    "preis": 1.80,
    "lieferant": "produkte@hofer.at"
}
products_collection.insert_one(product_data)

product_data = {
    "bezeichnung": "Gurke",
    "verfallsdatum": "01.02.2024",
    "standort": "Hofer - Lerchenfelder Str. 14, 1080 Wien",
    "preis": 1.10,
    "lieferant": "produkte@hofer.at"
}
products_collection.insert_one(product_data)