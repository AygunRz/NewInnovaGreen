import './App.css';
import '../node_modules/bootstrap-dark-5/dist/css/bootstrap-dark.min.css';
import '../node_modules/bootstrap/dist/js/bootstrap.bundle';
import "../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";
import { ApolloClient, InMemoryCache, ApolloProvider } from '@apollo/client';

import Home from './pages/Home';
import {
    BrowserRouter as Router,
    Routes,
    Route
} from "react-router-dom";
import Login from './pages/Login';
import Signup from './pages/Signup';
import NewFood from './pages/NewFood'
import MyOrder from './pages/MyOrder';
import SupplierProducts from './pages/SupplierProducts';
import {useEffect} from "react";
import CartPage from "./pages/CartPage";
import CheckoutPage from './pages/CheckoutPage';
import AdminPage from "./pages/AdminPage";
import SuccessPage from "./pages/SuccessPage"


const client = new ApolloClient({
  uri: 'http://localhost:5002/graphql',
  cache: new InMemoryCache(),
  onError: ({ networkError, graphQLErrors }) => {
    if (graphQLErrors)
      graphQLErrors.forEach(({ message, locations, path }) =>
        console.log(`[GraphQL error]: Message: ${message}, Location: ${locations}, Path: ${path}`),
      );
    if (networkError) console.log(`[Network error]: ${networkError}`);
  }
});



function App() {

    useEffect(() => {
        const handleTabClose = (event) => {
            localStorage.clear();
        };

        window.addEventListener('beforeunload', handleTabClose);

        return () => {
            window.removeEventListener('beforeunload', handleTabClose);
        };
    }, []);

    return (
        <ApolloProvider client={client}>
                <Router>
                    <div>
                        <Routes>
                            <Route exact path="/" element={<Home />} />
                            <Route exact path="/login" element={<Login />} />
                            <Route exact path="/signup" element={<Signup />} />
                            <Route exact path="/newfood" element={<NewFood />} />
                            <Route exact path="/myorder" element={<MyOrder />} />
                            <Route exact path="/new-food" element={<NewFood/>} />
                            <Route exact path="/my-products" element={<SupplierProducts/>} />
                            <Route exact path="/cartPage" element={<CartPage/>} />
                            <Route exact path="/checkoutPage" element={<CheckoutPage/>} />
                            <Route exact path="/adminPage" element={<AdminPage/>} />
                            <Route exact path="/successPage" element={<SuccessPage/>} />
                        </Routes>
                    </div>
                </Router>
        </ApolloProvider>
    )
}

export default App;