import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Badge from "@mui/material/Badge";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart"
import Modal from '../Modal';
import CartPage from '../pages/CartPage';

// Navbar for top-level navigation
export default function Navbar(props) {
    // State to control the visibility of the cart view
    const [cartView, setCartView] = useState(false)
    // Set item in local storage (login and logout)
    localStorage.setItem('temp', "first")
    let navigate = useNavigate();

    const userRole = localStorage.getItem("userRole");
    // Log out User
    const handleLogout = () => {
        localStorage.clear();
        navigate("/login")
    }

    const loadCart = () => {
        navigate('/CartPage');
    }

    // const items = useCart();
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-dark bg-success position-sticky"
                style={{ boxShadow: "0px 10px 20px black", filter: 'blur(20)', position: "fixed", zIndex: "10", width: "100%" }}>
                <div className="container-fluid">
                    <span className="navbar-brand fs-1 fst-italic" to="/">InnovaGreen</span>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            {/* Only show Home when Kunde or not logged in */}
                            {(!localStorage.getItem("token") || userRole === 'Kunde') && (
                                <li className="nav-item">
                                    <Link className="nav-link fs-5 mx-3 active" aria-current="page" to="/">Home</Link>
                                </li>
                            )}
                            {/* Only show My Orders when Kunde */}
                            {localStorage.getItem("token") && userRole === 'Kunde' && (
                                <li className="nav-item">
                                    <Link className="nav-link fs-5 mx-3 active" to="/myorder">My Orders</Link>
                                </li>
                            )}
                            {/* Only show My Products and New Product when Lieferant */}
                            {localStorage.getItem("token") && userRole === 'Lieferant' && (
                                <>
                                    <li className="nav-item">
                                        <Link className="nav-link fs-5 mx-3 active" to="/my-products">My Products</Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link fs-5 mx-3 active" to="/new-food">New Product</Link>
                                    </li>
                                </>
                            )}
                            {/* Only show Admin Page when Admin */}
                            {localStorage.getItem("token") && userRole === 'Admin' && (
                                <>
                                    <li className="nav-item">
                                        <Link className="nav-link fs-5 mx-3 active" to="/adminPage">Admin Page</Link>
                                    </li>
                                </>
                            )}
                        </ul>
                        {(!localStorage.getItem("token")) ? (
                            <form className="d-flex">
                                <Link className="btn bg-white text-success mx-1" to="/login">Login</Link>
                                <Link className="btn bg-white text-success mx-1" to="/signup">Signup</Link>
                            </form>
                        ) : (
                            <div>
                                {userRole === 'Kunde' && (
                                    <div className="btn bg-white text-success mx-2" onClick={loadCart}>
                                        <Badge color="secondary" badgeContent={0}>
                                            <ShoppingCartIcon />
                                        </Badge>
                                        Cart
                                    </div>
                                )}
                                {cartView && <Modal onClose={() => setCartView(false)}><CartPage /></Modal>}
                                <button onClick={handleLogout} className="btn bg-white text-success">Logout</button>
                            </div>
                        )}
                    </div>
                </div>
            </nav>
        </div>
    );
}