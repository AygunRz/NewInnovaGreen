import React from "react";

export default function Footer() {
    return (
        <div><div className="container">
            <footer className="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
                <div className="col-md-4 d-flex align-items-center">
                    <a href="/" className="mb-3 me-2 mb-md-0 text-muted text-decoration-none 1h-1">
                    </a>
                    <span className="text-muted">© 2024 <i>InnovaGreen</i>, Inc</span>
                </div>

                <ul className="nav col-md-4 jusify-content-end list-unstyled d-flex">
                    <li className="ms-3"><a className="text-muted" href="/">
                        <svg className="bi" width="24" height="24">
                            <use></use>
                        </svg>
                    </a></li>
                    <li className="ms-3"><a className="text-muted" href="/">
                        <svg className="bi" width="24" height="24">
                            <use></use>
                        </svg>
                    </a></li>
                    <li className="ms-3"><a className="text-muted" href="/">
                        <svg className="bi" width="24" height="24">
                            <use></use>
                        </svg>
                    </a></li>
                </ul>
                <div className="col-md-4 d-flex align-items-right">
                    <span className="text-muted"><i>Images from: </i>https://unsplash.com and https://images.pexels.com</span>
                </div>
            </footer>
        </div>
        </div>
    )
}