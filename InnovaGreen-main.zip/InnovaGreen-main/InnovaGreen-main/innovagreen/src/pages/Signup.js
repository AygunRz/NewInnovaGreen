import React, { useState } from 'react';
import { useMutation, gql } from '@apollo/client';
import { useNavigate, Link } from "react-router-dom";
import Navbar from '../components/Navbar';

const SIGNUP_MUTATION = gql`
    mutation Register($name: String!, $email: String!, $address: String!, $password: String!, $role: String!) {
        register(name: $name, email: $email, address: $address, password: $password, role: $role) {
            ok
            authToken
            message
        }
    }
`;

export default function Login() {
    const [inputdata, setInputData] = useState({ name:"", email: "", address: "", password: "", role: "" });
    let navigate = useNavigate();
    const [register, { data, loading, error }] = useMutation(SIGNUP_MUTATION);

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await register({ variables: { name: inputdata.name, email: inputdata.email, address: inputdata.address, password: inputdata.password, role: inputdata.role } });

            if (response.data.register.ok) {
                console.log(response)
                localStorage.setItem('userEmail', inputdata.email);
                localStorage.setItem('token', response.data.register.authToken);
                localStorage.setItem('userRole', inputdata.role);

                if (inputdata.role === 'Kunde') {
                    navigate("/"); // Redirect to home for Kunde
                } else if (inputdata.role === 'Lieferant') {
                    navigate("/newfood"); // Redirect to newfood for Lieferant
                }
            } else {
                alert("Email address already in use");
            }
        } catch (e) {
            console.error('Error during sign up:', e);
            alert('Sign up failed.');
        }
    };

    const onChange = (e) => {
        setInputData({ ...inputdata, [e.target.name]: e.target.value });
    };

    return (
        <div style={{
            backgroundImage: 'url("https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")',
            backgroundSize: 'cover',
            height: '100vh'
        }}>
            <div>
                <Navbar/>
            </div>

            <div className='container'>
                <form className='w-50 m-auto mt-5 border bg-dark border-success rounded' onSubmit={handleSubmit}>
                    <div className="m-3 text-light">
                        <label htmlFor="name" className="form-label">Name</label>
                        <input type="text" className="form-control" name='name' value={inputdata.name}
                               onChange={onChange} aria-describedby="emailHelp" required="true"/>
                    </div>
                    <div className="m-3 text-light">
                        <label htmlFor="email" className="form-label">Email address</label>
                        <input type="email" className="form-control" name='email' value={inputdata.email}
                               onChange={onChange} aria-describedby="emailHelp" required="true"/>
                    </div>
                    <div className="m-3 text-light">
                        <label htmlFor="address" className="form-label">Address</label>
                        <fieldset>
                            <input type="text" className="form-control" name='address' value={inputdata.address}
                                   onChange={onChange} aria-describedby="emailHelp" required="true"/>
                        </fieldset>
                    </div>
                    <div className="m-3 text-light">
                        <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
                        <input type="password" className="form-control" value={inputdata.password} onChange={onChange}
                               name='password' required="true"/>
                    </div>
                    <div className="m-3 text-light">
                        <label htmlFor="role" className="form-label">Role</label>
                        <div>
                            <input type="radio" value="Kunde" name="role" onChange={onChange} checked={inputdata.role === "Kunde"} required="true"/> Kunde
                            <br></br>
                            <input type="radio" value="Lieferant" name="role" onChange={onChange} checked={inputdata.role === "Lieferant"} required="true"/> Lieferant
                        </div>
                    </div>
                    <button type="submit" className="m-3 btn btn-success">Submit</button>
                </form>
            </div>
        </div>
    )
}