import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';

function CartPage() {
    const [cartItems, setCartItems] = useState([]);
    const [deliveryOption, setDeliveryOption] = useState('selfPickup'); // Default to self pickup
    const navigate = useNavigate();

    useEffect(() => {
        const loadedCart = JSON.parse(localStorage.getItem('cart')) || [];
        setCartItems(loadedCart);
    }, []);

    const removeFromCart = (index) => {
        const newCartItems = cartItems.filter((_, itemIndex) => itemIndex !== index);
        setCartItems(newCartItems);
        localStorage.setItem('cart', JSON.stringify(newCartItems));
    };

    const handleCheckout = () => {
        navigate('/checkoutPage');
    };

    const deliveryCharge = deliveryOption === 'homeDelivery' ? 2 : 0;
    localStorage.setItem('deliveryCharge', deliveryCharge.toString());
    const totalPrice = cartItems.reduce((total, item) => total + item.preis, 0) + deliveryCharge;


    if (cartItems.length === 0) {
        return (
        <div style={{
            backgroundImage: 'url("https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")',
            backgroundSize: 'cover',
            height: '100vh'
        }}>
                <Navbar />
                <div className='container mt-5'>
                    <div className="row">
                        <div className="col-12 mt-5">
                            <div className="card bg-dark text-white border-success rounded">
                                <div className="card-header">
                                    <h1>My Shopping Cart</h1>
                                </div>
                                <div className="card-body">
                                    <p>No items in the shopping cart</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

        return (
        <div style={{
            backgroundImage: 'url("https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")',
            backgroundSize: 'cover',
            height: '100vh'
        }}>
            <Navbar />
            <div className='container mt-5 d-flex justify-content-center'>
                <div className="row">
                    <div className="col-12 mt-5">
                        <div className="border bg-secondary text-white border-success rounded">
                            <div className="card-header">
                                <h1>My Shopping Cart</h1>
                            </div>
                            <div style={{ maxHeight: 'calc(80vh - 200px)', overflowY: 'auto' }}>
                            <table className="table">
                                <thead className="thead-dark">
                                <tr>
                                    <th>Product</th>
                                    <th>Location</th>
                                    <th>Price</th>
                                    <th>Expiration date</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                {cartItems.map((item, index) => (
                                    <tr key={index}>
                                        <td>{item.bezeichnung}</td>
                                        <td>{item.standort}</td>
                                        <td>{item.preis}€</td>
                                        <td>{item.verfallsdatum}</td>
                                        <td>
                                            <button className="btn btn-danger"
                                                    onClick={() => removeFromCart(index)}>Remove
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                                </tbody>
                                </table>
                            </div>
                            <div style={{ padding: 15 }}>
                                <label htmlFor="delivery-option">Choose a delivery option:</label>
                                <select id="delivery-option" className="form-select"
                                        value={deliveryOption}
                                        onChange={(e) => setDeliveryOption(e.target.value)}>
                                    <option value="selfPickup">Self Pickup</option>
                                    <option value="homeDelivery">Home Delivery (additional 2€)</option>
                                </select>
                            </div>
                            <div className="fw-bold" style={{padding: 5}}>
                                Total price: {totalPrice.toFixed(2)}€
                            </div>
                            <div style={{padding: 15}}>
                                <button className="btn btn-success mt-3 text-white" onClick={handleCheckout}>Checkout</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CartPage;
