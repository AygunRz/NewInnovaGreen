import React, { useState } from 'react';
import { useMutation, gql } from '@apollo/client';
import { useNavigate, Link } from "react-router-dom";
import Navbar from '../components/Navbar';

const NEWFOOD_MUTATION = gql`
    mutation NewFood($bezeichnung: String!, $standort: String!, $verfallsdatum: String!, $preis: Float!, $lieferant: String!) {
        newFood(bezeichnung: $bezeichnung, standort: $standort, verfallsdatum: $verfallsdatum, preis: $preis, lieferant: $lieferant) {
            ok
            message
        }
    }
`;

export default function NewFood() {
    const [inputdata, setInputData] = useState({ bezeichnung:"", standort: "", verfallsdatum: "", preis: 0, lieferant: ""});
    const [showProducts, setShowProducts] = useState(true);
    const navigate = useNavigate();
    const [newFood, { loading: mutationLoading, error: mutationError }] = useMutation(NEWFOOD_MUTATION);

    const validateInput = () => {
        return inputdata.bezeichnung && inputdata.standort && inputdata.verfallsdatum && inputdata.preis;
    };
    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!validateInput()) {
            alert("Please fill in all fields!");
            return;
        }

        try {
            const response = await newFood({ variables: { bezeichnung: inputdata.bezeichnung, standort: inputdata.standort, verfallsdatum: inputdata.verfallsdatum, preis: parseFloat(inputdata.preis), lieferant: localStorage.getItem('userEmail') } });

            if (response.data.newFood.ok) {
                alert("Product successfully added");
            } else {
                console.error('Server response:', response);
                alert("Could not upload food" + response.data.newFood.message);
            }
        } catch (e) {
            console.error('Could not upload food', e);
            alert(`Could not upload food: ${e.message}, Network error: ${e.networkError}, GraphQL error: ${e.graphQLErrors}`);
        }
    };

    const onChange = (e) => {
        setInputData({ ...inputdata, [e.target.name]: e.target.value });
    };

    return (
        <div style={{
            backgroundImage: 'url("https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")',
            backgroundSize: 'cover',
            height: '100vh'
        }}>
            <div>
                <Navbar/>
                <div className='container mt-5 d-flex justify-content-center'>
                </div>
            </div>


            <div className='container'>
                <form className='w-50 m-auto mt-5 border bg-secondary text-white border-success rounded' onSubmit={handleSubmit}>
                    <div className="card-header">
                        <h1>Add new Product</h1>
                    </div>
                    <div className="m-3">
                        <label htmlFor="bezeichnung" className="form-label">Product</label>
                        <input type="text" className="form-control" name='bezeichnung' value={inputdata.bezeichnung}
                               onChange={onChange} aria-describedby="emailHelp" required="true"/>
                    </div>
                    <div className="m-3">
                        <label htmlFor="standort" className="form-label">Location</label>
                        <input type="text" className="form-control" name='standort' value={inputdata.standort}
                               onChange={onChange} aria-describedby="emailHelp" required="true"/>
                    </div>
                    <div className="m-3">
                        <label htmlFor="verfallsdatum" className="form-label">Expiration date</label>
                        <input type="text" className="form-control" name='verfallsdatum' value={inputdata.verfallsdatum}
                               onChange={onChange} aria-describedby="emailHelp" required="true"/>
                    </div>
                    <div className="m-3">
                        <label htmlFor="preis" className="form-label">Price</label>
                        <input type="number" className="form-control" name='preis' value={inputdata.preis}
                               onChange={onChange} aria-describedby="emailHelp" required="true"/>
                    </div>
                    <div className="m-3">
                        <label htmlFor="lieferant" className="form-label">Supplier</label>
                        <input type="text" className="form-control" name='lieferant'
                               value={localStorage.getItem('userEmail')}
                               onChange={onChange} aria-describedby="emailHelp"/>
                    </div>
                    <button type="submit" className="m-3 btn btn-success">Submit</button>
                </form>
            </div>
        </div>
    )
}