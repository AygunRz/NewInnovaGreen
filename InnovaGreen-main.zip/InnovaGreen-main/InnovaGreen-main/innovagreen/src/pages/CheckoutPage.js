import React, {useEffect, useState} from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import {useMutation, gql} from "@apollo/client";


const CHECKOUT_MUTATION = gql`
    mutation Checkout($cardNumber: String!, $expiryDate: String!, $cvv: String!, $cardHolder: String!, $totalPrice: Float!, $cartItems: [CartItemType!], $email:String!) {
        checkout(cardNumber: $cardNumber, expiryDate: $expiryDate, cvv: $cvv, cardHolder: $cardHolder, totalPrice: $totalPrice, cartItems: $cartItems, email: $email) {
            ok
            message
        }
    }
`;

export default function Checkout() {
    const [creditCardDetails, setCreditCardDetails] = useState({
        cardNumber: "",
        expiryDate: "",
        cvv: "",
        cardHolder: "",
    });

    const [cartData, setCartData] = useState([]);
    useEffect(() => {
        // Loads the shopping cart from localStorage
        const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
        setCartData(cartItems);
    }, []);

    const [checkout, { data, loading, error }] = useMutation(CHECKOUT_MUTATION);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
        let totalPrice = cartData.reduce((total, item) => total + item.preis, 0);
        totalPrice += parseFloat(localStorage.getItem('deliveryCharge'));
        totalPrice = totalPrice.toFixed(2);

        try {
            const response = await checkout({
                variables: {
                    ...creditCardDetails, totalPrice, cartItems: cartItems, email: localStorage.getItem('userEmail')
                }
            });

            if (response.data && response.data.checkout.ok) {
                alert('Transaction successful!');
                localStorage.setItem('recentOrder', JSON.stringify(cartData)); // Speichern der Bestelldaten
                localStorage.removeItem('cart')
                navigate('/successPage'); // Navigieren zur SuccessPage
            } else {
                alert('Invalid credit card details: ' + response.data.checkout.message);
            }
        } catch (err) {
            console.error('Error during checkout processing', err);
            alert('An error has occurred');
        }
    };

    const onChange = (e) => {
        setCreditCardDetails({ ...creditCardDetails, [e.target.name]: e.target.value });
    };


    return (
        <div style={{
            backgroundImage: 'url("https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")',
            backgroundSize: 'cover',
            height: '100vh'
        }}>
            <Navbar/>
            <div className='container mt-5 d-flex justify-content-center'>
                <div className="row">
                    <div className="col-12 mt-5">
                        <div className="border border-success rounded"
                             style={{backgroundColor: 'rgba(33, 37, 41, 0.8)', padding: '20px'}}>
                            <form onSubmit={handleSubmit} style={{color: 'white'}}>
                                <div className="form-group mb-3">
                                    <label>Card Number</label>
                                    <input type="text" className="form-control" name="cardNumber"
                                           onChange={onChange} style={{background: 'grey', color: 'white'}}/>
                                </div>
                                <div className="form-group mb-3">
                                    <label>Expiry Date</label>
                                    <input type="text" className="form-control" name="expiryDate"
                                           onChange={onChange} style={{background: 'grey', color: 'white'}}/>
                                </div>
                                <div className="form-group mb-3">
                                    <label>CVV</label>
                                    <input type="text" className="form-control" name="cvv"
                                           onChange={onChange} style={{background: 'grey', color: 'white'}}/>
                                </div>
                                <div className="form-group mb-3">
                                    <label>Card Holder's Name</label>
                                    <input type="text" className="form-control" name="cardHolder"
                                           onChange={onChange} style={{background: 'grey', color: 'white'}}/>
                                </div>
                                <button type="submit" className="btn btn-primary mt-3">Pay</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
