import React, { useState } from 'react';
import { useQuery, useMutation, gql } from '@apollo/client';
import Navbar from '../components/Navbar';

const GET_MY_PRODUCTS = gql`
    query GetMyProducts($lieferantEmail: String!) {
        myProducts(lieferantEmail: $lieferantEmail) {
            produktID
            bezeichnung
            verfallsdatum
            standort
            preis
        }
    }
`;

const REMOVE_PRODUCT = gql`
    mutation RemoveProduct($produktID: String!) {
        removeProduct(produktID: $produktID) {
            ok
            message
        }
    }
`;

const UPDATE_PRODUCT = gql`
    mutation UpdateProduct($produktID: String!, $bezeichnung: String, $verfallsdatum: String, $standort: String, $preis: Float) {
        updateProduct(produktID: $produktID, bezeichnung: $bezeichnung, verfallsdatum: $verfallsdatum, standort: $standort, preis: $preis) {
            ok
            message
        }
    }
`;

    const SupplierProducts = () => {
    const lieferantEmail = localStorage.getItem('userEmail');
    const { loading, error, data, refetch } = useQuery(GET_MY_PRODUCTS, {
        variables: { lieferantEmail: lieferantEmail }, fetchPolicy: 'network-only'
    });
    console.log({ loading, error, data });

    const removeFromProducts = (produktID) => {
        removeProduct({ variables: { produktID: produktID } });
    };

    const [removeProduct] = useMutation(REMOVE_PRODUCT, {
        onCompleted: () => refetch(),
        update(cache, { data: { removeProduct } }) {
            if (removeProduct.success) {
            }
        },
    });

    const [updateProduct] = useMutation(UPDATE_PRODUCT, {
        onCompleted: () => refetch()
    });

    const [editingProduct, setEditingProduct] = useState(null);

    const startEditing = (product) => {
        setEditingProduct({ ...product });
    };

    const handleInputChange = (e, field) => {
        setEditingProduct({ ...editingProduct, [field]: e.target.value });
    };

    const submitProductChanges = () => {
        updateProduct({ variables: { ...editingProduct } });
        setEditingProduct(null); // Closes the form after saving
    };

    const changeProductDetails = (produktID) => {
    const newBezeichnung = "";
    const newVerfallsdatum = "";
    const newStandort = "";
    const newPreis = 123.45;

    updateProduct({ variables: { produktID, bezeichnung: newBezeichnung, verfallsdatum: newVerfallsdatum, standort: newStandort, preis: newPreis } });
    };

    const renderProducts = () => {
        if (loading) return <p>Loading...</p>;
        if (error) return <p>Error: {error.message}</p>;

    return (
    <div className='container'>
        <div className="row">
            <div className="col-12 mt-5">
                <div className="border bg-secondary text-white border-success rounded">
                    <div className="card-header">
                        <h1>My Products</h1>
                    </div>
                    <div style={{maxHeight: 'calc(80vh - 200px)', overflowY: 'auto'}}>
                    <table className="table">
                        <thead className="thead-dark">
                        <tr>
                            <th>Product</th>
                            <th>Expiration date</th>
                            <th>Location</th>
                            <th>Price</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        {data.myProducts.map((product) => (
                            <React.Fragment key={product.produktID}>
                                {editingProduct && editingProduct.produktID === product.produktID ? (
                                    <tr>
                                        <td><input type="text" value={editingProduct.bezeichnung}
                                                   onChange={(e) => handleInputChange(e, 'bezeichnung')}/></td>
                                        <td><input type="text" value={editingProduct.verfallsdatum}
                                                   onChange={(e) => handleInputChange(e, 'verfallsdatum')}/></td>
                                        <td><input type="text" value={editingProduct.standort}
                                                   onChange={(e) => handleInputChange(e, 'standort')}/></td>
                                        <td><input type="text" value={editingProduct.preis}
                                                   onChange={(e) => handleInputChange(e, 'preis')}/></td>
                                        <td>
                                            <button onClick={submitProductChanges}>Save changes</button>
                                        </td>
                                    </tr>
                                ) : (
                                    <tr key={product.produktID}>
                                        <td>{product.bezeichnung}</td>
                                        <td>{product.verfallsdatum}</td>
                                        <td>{product.standort}</td>
                                        <td>{product.preis}€</td>
                                        <td>
                                            <button className="btn btn-success mr-2"
                                                    onClick={() => startEditing(product)}>Change
                                            </button>
                                            <button className="btn btn-danger"
                                                    onClick={() => removeFromProducts(product.produktID)}>Remove
                                            </button>
                                        </td>
                                    </tr>
                                )}
                            </React.Fragment>
                        ))}
                        </tbody>
                    </table>
                </div>
                </div>
            </div>
        </div>
    </div>
    );
    };

        return (
            <div style={{
                backgroundImage: 'url("https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")',
            backgroundSize: 'cover',
            height: '100vh'
        }}>
            <Navbar />
            <div className='container mt-5'>
                {renderProducts()}
            </div>
        </div>
    );
};

export default SupplierProducts;