import React, { useEffect, useState } from "react";
import Footer from '../components/Footer'
import Navbar from '../components/Navbar'
import { gql, useQuery } from '@apollo/client';
import { useLazyQuery } from '@apollo/client';
import { useNavigate } from 'react-router-dom';
import {auto} from "@popperjs/core";

const SEARCH_PRODUCTS = gql`
  query SearchProducts($keyword: String!, $location: String, $minPrice: Float, $maxPrice: Float) {
    searchProducts(keyword: $keyword, location: $location, minPrice: $minPrice, maxPrice: $maxPrice) {
      produktID
      bezeichnung
      verfallsdatum
      standort
      preis
      lieferant
    }
  }
`;

export default function Home() {

    const [foodCat, setFoodCat] = useState([]) // Food categories
    const [foodItems, setFoodItems] = useState([]) // Food items
    const [search, setSearch] = useState('') // Search input

    const [location, setLocation] = useState('');
    const [minPrice, setMinPrice] = useState(0);
    const [maxPrice, setMaxPrice] = useState(1000);

    // Use Apollo Client to fetch data
    const [searchProducts, { loading, data, error }] = useLazyQuery(SEARCH_PRODUCTS, {fetchPolicy: 'network-only'});

    const [searchData, setSearchData] = useState(null);
    const [showResults, setShowResults] = useState(false);

    let navigate = useNavigate();

    const handleProductSelect = (produktID, bezeichnung, verfallsdatum, standort, preis, lieferant) => {
        if (!isLoggedIn()) {
            // navigate('/login'); // Redirect to login page if not logged in
            alert("Log In to add Items to your cart!")
        } else {
            // Create a product object
            let produkt = {
                produktID: produktID,
                bezeichnung: bezeichnung,
                verfallsdatum: verfallsdatum,
                standort: standort,
                preis: preis,
                lieferant: lieferant
            };

            // Add the product to the shopping cart
            addToCart(produkt);
        }
    };

    // Adds a product to the shopping cart
    function addToCart(produkt) {
        // Retrieve the current shopping cart from localStorage
        let cart = JSON.parse(localStorage.getItem('cart')) || [];

        // Check if the product is already in the shopping cart
        // Assuming each product has a unique 'productID'
        const isProductInCart = cart.some(item => item.produktID === produkt.produktID);

        if (!isProductInCart) {
            // Add the new product if it is not yet in the shopping cart
            cart.push(produkt);
        }
        // Save the updated shopping cart in localStorage
        localStorage.setItem('cart', JSON.stringify(cart));
    }


    const handleSearch = () => {
        searchProducts({
            variables: { keyword: search, location, minPrice, maxPrice },
        });
        setShowResults(true); // Show results when search is performed
    };

    const handleClearAll = () => {
        setLocation('');
        setSearch('');
        setMinPrice(0);
        setMaxPrice(1000);
        setShowResults(false); // Reset this to hide results
    };


    const isLoggedIn = () => {
        return !!localStorage.getItem('token'); // Checks if 'token' exists in localStorage
    };

    const renderProducts = () => {
        if (!showResults) return null; // Don't render if showResults is false
        // console.log(searchData)
        if (loading) return <p>Loading...</p>;
        if (error) return <p>Error: {error.message}</p>;
        if (!data || !data.searchProducts) return <p></p>;


    return (
        <ul className="product-list" style={{maxHeight: 450, overflowY: auto, marginBottom: 20}}>
            {data.searchProducts.map(({ produktID, bezeichnung, verfallsdatum, standort, preis, lieferant }) => (
                <li key={produktID} className="product-item">
                    <div className="product-info">
                        <h3 className="product-title">{bezeichnung}</h3>
                        <p className="product-details">Location: {standort} | Price: {preis}€ | Expiration date: {verfallsdatum}</p>
                    </div>
                    <button className="btn btn-add" onClick={() => handleProductSelect(produktID, bezeichnung, verfallsdatum, standort, preis, lieferant)}>Add</button>
                </li>
            ))}
        </ul>
    );
};

    return (
        <div>
            <div>
                <Navbar/>
            </div>
            <div>
                <div id="carouselExampleFade" className="carousel slide carousel-fade " data-bs-ride="carousel">

                    <div className="carousel-inner " id='carousel'>
                        <div className=" carousel-caption  " style={{zIndex: "9"}}>

                            <div>{renderProducts()}</div>

                            {/* Location Input */}
                            <div className=" d-flex justify-content-center">  {/* justify-content-center, copy this <form> from navbar for search box */}
                                <input className="form-control me-2 w-75 bg-white text-dark"
                                       type="search"
                                       placeholder="Location..." aria-label="Search" value={location}
                                       onChange={(e) => {setLocation(e.target.value)}}/>
                            </div>

                            {/* Food Input */}
                            <div
                                className=" d-flex justify-content-center">  {/* justify-content-center, copy this <form> from navbar for search box */}
                                <input className="form-control me-2 w-75 bg-white text-dark"
                                       type="search"
                                       placeholder="Search in here..." aria-label="Search" value={search}
                                       onChange={(e) => {setSearch(e.target.value)}}/>
                            </div>

                            {/* Min and Max Input */}
                            <div className="d-flex justify-content-center">
                                <input
                                    className="form-control me-2"
                                    style={{
                                        width: '37.2%',
                                        backgroundColor: 'white',
                                        color: 'black'
                                    }} // Adjust width and color
                                    type="number"
                                    placeholder="Min Price"
                                    defaultValue={0}
                                    onChange={(e) => setMinPrice(e.target.value === '' ? '' : parseFloat(e.target.value))}
                                />
                                <input
                                    className="form-control me-2"
                                    style={{
                                        width: '37.2%',
                                        backgroundColor: 'white',
                                        color: 'black'
                                    }} // Adjust width and color
                                    type="number"
                                    placeholder="Max Price"
                                    defaultValue={1000}
                                    onChange={(e) => setMaxPrice(e.target.value === '' ? '' : parseFloat(e.target.value))}
                                />
                            </div>

                            {/* Search and Clear All Button */}
                            <div className="d-flex justify-content-center">
                                <button className="btn btn-success me-2" onClick={handleSearch}>Search</button>
                                <button className="btn text-white bg-danger" onClick={handleClearAll}>Clear All</button>
                            </div>


                        </div>
                        <div className="carousel-item active">
                            <img src="https://source.unsplash.com/random/900x415/?burger" className="d-block w-100  "
                                 style={{filter: "brightness(30%)"}} alt="..."/>
                        </div>

                        <div className="carousel-item">
                            <img src="https://source.unsplash.com/random/900x415/?pastry" className="d-block w-100 "
                                 style={{filter: "brightness(30%)"}} alt="..." />
                        </div>
                        <div className="carousel-item">
                            <img src="https://source.unsplash.com/random/900x415/?barbeque" className="d-block w-100 "
                                 style={{filter: "brightness(30%)"}} alt="..." />
                        </div>
                    </div>
                </div>

            </div>

            <Footer/>
        </div>
    )
}