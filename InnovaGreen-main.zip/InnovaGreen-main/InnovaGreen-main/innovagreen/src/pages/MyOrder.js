import React, { useState, useCallback } from 'react';
import {useQuery, gql, useMutation} from '@apollo/client';
import Navbar from '../components/Navbar';

const GET_ORDERS = gql`
  query GetMyOrders($email: String!) {
    myOrders(email: $email) {
      orderID
      totalPrice
      orderDate
      email
      cartItems {
          produktID
          bezeichnung
          verfallsdatum
          standort
          preis
          lieferant
      }
    }
  }
`;

const CANCEL_ORDER_MUTATION = gql`
  mutation CANCEL_ORDER($orderID: String!) {
      cancelOrder(orderID: $orderID) {
          ok
          message
      }
  }
`;

const OrdersList = () => {
  const { loading, error, data, refetch } = useQuery(GET_ORDERS, {
    variables: { email: localStorage.getItem('userEmail') },
    fetchPolicy: 'network-only'
  });

  const [cancelOrder, { dataCancel, loadingCancel, errorCancel }] = useMutation(CANCEL_ORDER_MUTATION);

  // const [selectedOrder, setSelectedOrder] = useState(null);
  const [selectedOrderId, setSelectedOrderId] = useState('');

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error :(</p>;

  const handleOrderChange = (e) => {
    setSelectedOrderId(e.target.value);
  }

    const selectedOrder = data.myOrders.find(order => order.orderID === selectedOrderId);
    let deliveryPrice = 0;
    if (selectedOrder != null) {
        deliveryPrice = (selectedOrder.totalPrice - selectedOrder.cartItems.reduce((total, item) => total + item.preis, 0)).toFixed(2);
    }

  const handleCancelOrder = async (orderID) => {
    try {
      const response = await cancelOrder({ variables: { orderID: orderID } });

      if (response.data.cancelOrder.ok) {
        alert("Order successfully canceled.");
        refetch();  // Re-fetch the orders
      }
    } catch (e) {
      console.error(e);
      alert('Error during canceling order: ' + e.message);
    }
  };


  return (
    <div style={{
        backgroundImage: 'url("https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")',
        backgroundSize: 'cover',
        height: '100vh'
    }}>

      <Navbar />
      <div className='container mt-5 d-flex justify-content-center'>
        <div className="row">
          <div className="col-12 mt-5">
            <select value={selectedOrderId} onChange={handleOrderChange} className="form-select mb-3">
              <option value="">Select an Order</option>
              {data.myOrders.map((order) => (
                <option key={order.orderID} value={order.orderID}>
                  Your Order from: {order.orderDate}
                </option>
              ))}
            </select>

            {selectedOrder && (
                <div className="border border-success rounded"
                     style={{backgroundColor: 'rgba(33, 37, 41, 0.8)', padding: '20px', color: 'white'}}>
                  <h3>Your Order from: {selectedOrder.orderDate}</h3>
                  {selectedOrder.cartItems.map((item) => (
                      <div key={item.produktID}>
                        <p>{item.bezeichnung} - {item.preis}€</p>
                      </div>
                  ))}
                    {selectedOrder != null ? (
                        <div>
                            <p>Delivery - {deliveryPrice}€</p>
                        </div>
                    ) : ""}
                  <hr></hr>
                  <h4>Total: {selectedOrder.totalPrice}€</h4>
                  <br></br>
                  <button className="btn btn-danger" onClick={() => handleCancelOrder(selectedOrder.orderID)}>
                    Cancel
                  </button>
                </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrdersList;