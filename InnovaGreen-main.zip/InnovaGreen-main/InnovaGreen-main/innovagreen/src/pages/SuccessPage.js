import React from 'react';
import Navbar from '../components/Navbar';

export default function SuccessPage() {
    const order = JSON.parse(localStorage.getItem('recentOrder')) || [];
    const orderData = JSON.parse(localStorage.getItem('recentOrder')) || [];
    let totalPrice = orderData.reduce((total, item) => total + item.preis, 0);
    const delivery = parseFloat(localStorage.getItem('deliveryCharge'))
    totalPrice = (totalPrice+delivery).toFixed(2);


    return (
        <div style={{
            backgroundImage: 'url("https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")',
            backgroundSize: 'cover',
            height: '100vh'
        }}>
            <Navbar />
            <div className='container mt-5'>
                <div className="row">
                    <div className="col-12 mt-5">
                        <div className="card bg-dark text-white border-success rounded">
                            <div className="card-header">
                                <h1>Order Confirmation</h1>
                            </div>
                            <div className="card-body">
                                <h2>Your payment was successful! Thank you for your order!</h2>
                                <p>You have ordered the following products:</p>
                                <ul>
                                    {order.map((item, index) => (
                                        <li key={index}>{item.bezeichnung} - {item.preis}€</li>
                                    ))}
                                    <li key={0}>{'Delivery'} - {delivery}€</li>
                                </ul>
                                <p>Total Price: {totalPrice}€</p>
                                <p>{delivery > 0 ? "Your order is expected to be delivered tomorrow!" : "You can pick up your order today!"}</p>
                                <p>If you wish to cancel or modify your order, please visit the "My Orders" page where you can manage your orders.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
