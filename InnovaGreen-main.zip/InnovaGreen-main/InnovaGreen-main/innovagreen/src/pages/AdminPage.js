import React, { useState } from 'react';
import { useQuery, useMutation, gql } from '@apollo/client';
import Navbar from '../components/Navbar';

const GET_USERS = gql`
    query GetUsers {
      allUsers {
          id
          name
          email
          role
        }
    }
`;

const REMOVE_USER = gql`
    mutation RemoveUser($userID: String!) {
        removeUser(userID: $userID) {
            ok
            message
        }
    }
`;

const UPDATE_USER = gql`
    mutation UpdateUser($id: String!, $name: String, $email: String, $role: String) {
        updateUser(id: $id, name: $name, email: $email, role: $role) {
            ok
            message
        }
    }
`;

const GET_PRODUCTS = gql`
    query GetProducts {
      allProducts {
          produktID
          bezeichnung
          verfallsdatum
          standort
          preis
        }
    }
`;

const REMOVE_PRODUCT = gql`
    mutation RemoveProduct($produktID: String!) {
        removeProduct(produktID: $produktID) {
            ok
            message
        }
    }
`;

const UPDATE_PRODUCT = gql`
    mutation UpdateProduct($produktID: String!, $bezeichnung: String, $verfallsdatum: String, $standort: String, $preis: Float) {
        updateProduct(produktID: $produktID, bezeichnung: $bezeichnung, verfallsdatum: $verfallsdatum, standort: $standort, preis: $preis) {
            ok
            message
        }
    }
`;

function AdminPage() {
    const { loading: loadingUsers, errorUsers, data: usersData, refetch: refetchUsers } = useQuery(GET_USERS);
    const { loading: loadingProducts, errorProducts, data: productsData, refetch: refetchProducts } = useQuery(GET_PRODUCTS);

    const [editingUser, setEditingUser] = useState(null);
    const [editingProduct, setEditingProduct] = useState(null);

    const removeFromProducts = (produktID) => {
        removeProduct({ variables: { produktID } });
    };
    const removeFromUsers = (userID) => {
        removeUser({ variables: { userID } });
    };

    const [removeProduct] = useMutation(REMOVE_PRODUCT, {
        onCompleted: () => refetchProducts(),
        update(cache, { data: { removeProduct } }) {
            if (removeProduct.success) {
            }
        },
    });
    const [removeUser] = useMutation(REMOVE_USER, {
        onCompleted: () => refetchUsers(),
        update(cache, { data: { removeUser } }) {
            if (removeUser.success) {
            }
        },
    });

    const [updateProduct] = useMutation(UPDATE_PRODUCT, {
        onCompleted: () => refetchProducts()
    });
    const [updateUser] = useMutation(UPDATE_USER, {
        onCompleted: () => refetchUsers()
    });

    if (loadingUsers || loadingProducts) return <p>Loading...</p>;

    const startProductEdit = (product) => {
        setEditingProduct({ ...product });
    };
    const startUserEdit = (user) => {
        setEditingUser({ ...user });
    };

    const handleInputChangeProduct = (e, field) => {
        setEditingProduct({ ...editingProduct, [field]: e.target.value });
    };
    const handleInputChangeUser = (e, field) => {
        setEditingUser({ ...editingUser, [field]: e.target.value });
    };

    const submitProductChanges = () => {
        updateProduct({ variables: { ...editingProduct } });
        setEditingProduct(null);
    };
    const submitUserChanges = () => {
        console.log(editingUser)
        updateUser({ variables: { ...editingUser } });
        setEditingUser(null);
    };

    const renderUsers = () => {
        if (loadingUsers) return <p>Loading...</p>;
        if (errorUsers) return <p>Error: {errorUsers.message}</p>;

    return (
        <div className='container'>
            <div className="row">
                <div className="col-12 mt-5">
                    <div className="border bg-secondary text-white border-success rounded">
                        <div className="card-header">
                            <h1>Users</h1>
                        </div>
                        <div style={{ maxHeight: 'calc(80vh - 200px)', overflowY: 'auto' }}>
                        <table className="table">
                            <thead className="thead-dark">
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                {usersData.allUsers.map(user => (
                                    <React.Fragment key={user.id}>
                                        {editingUser && editingUser.id === user.id ? (
                                            <tr>
                                                <td><input type="text" value={editingUser.name}
                                                           onChange={(e) => handleInputChangeUser(e, 'name')}/>
                                                </td>
                                                <td><input type="text" value={editingUser.email}
                                                           onChange={(e) => handleInputChangeUser(e, 'email')}/>
                                                </td>
                                                <td>
                                                    <div onChange={(e) => handleInputChangeUser(e, 'role')}>
                                                        <input type="radio" value="Kunde" name="role"
                                                               checked={editingUser.role === "Kunde"}/> Kunde
                                                        <br></br>
                                                        <input type="radio" value="Lieferant" name="role"
                                                               checked={editingUser.role === "Lieferant"}/> Lieferant
                                                    </div>
                                                </td>
                                                <td>
                                                    <button onClick={submitUserChanges}>Save changes</button>
                                                </td>
                                            </tr>
                                        ) : (
                                            <tr>
                                                <td>{user.name}</td>
                                                <td>{user.email}</td>
                                                <td>{user.role}</td>
                                                <td>
                                                    <button className="btn btn-success mr-2"
                                                            onClick={() => startUserEdit(user)}>Edit
                                                    </button>
                                                    <button className="btn btn-danger"
                                                            onClick={() => removeFromUsers(user.id)}>Delete
                                                    </button>
                                                </td>
                                            </tr>
                                        )}
                                    </React.Fragment>
                                ))}
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
    };


    const renderProducts = () => {
        if (loadingProducts) return <p>Loading...</p>;
        if (errorProducts) return <p>Error: {errorProducts.message}</p>;

        return (
            <div className='container'>
            <div className="row">
                <div className="col-12 mt-5">
                    <div className="border bg-secondary text-white border-success rounded">
                        <div className="card-header">
                            <h1>Products</h1>
                        </div>
                        <div style={{ maxHeight: 'calc(80vh - 200px)', overflowY: 'auto' }}>
                        <table className="table">
                            <thead className="thead-dark">
                                <tr>
                                    <th>Product</th>
                                    <th>Expiration date</th>
                                    <th>Location</th>
                                    <th>Price</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                {productsData.allProducts.map(product => (
                                    <React.Fragment key={product.produktID}>
                                        {editingProduct && editingProduct.produktID === product.produktID ? (
                                            <tr>
                                                <td><input type="text" value={editingProduct.bezeichnung}
                                                           onChange={(e) => handleInputChangeProduct(e, 'bezeichnung')}/>
                                                </td>
                                                <td><input type="text" value={editingProduct.verfallsdatum}
                                                           onChange={(e) => handleInputChangeProduct(e, 'verfallsdatum')}/>
                                                </td>
                                                <td><input type="text" value={editingProduct.standort}
                                                           onChange={(e) => handleInputChangeProduct(e, 'standort')}/></td>
                                                <td><input type="text" value={editingProduct.preis}
                                                           onChange={(e) => handleInputChangeProduct(e, 'preis')}/></td>
                                                <td>
                                                    <button onClick={submitProductChanges}>Save changes</button>
                                                </td>
                                            </tr>
                                        ) : (
                                            <tr key={product.produktID}>
                                                <td>{product.bezeichnung}</td>
                                                <td>{product.verfallsdatum}</td>
                                                <td>{product.standort}</td>
                                                <td>{product.preis}€</td>
                                                <td>
                                                    <button className="btn btn-success mr-2"
                                                            onClick={() => startProductEdit(product)}>Edit
                                                    </button>
                                                    <button className="btn btn-danger"
                                                            onClick={() => removeFromProducts(product.produktID)}>Delete
                                                    </button>
                                                </td>
                                            </tr>
                                        )}
                                    </React.Fragment>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

    return (
        <div style={{
            backgroundImage: 'url("https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")',
            backgroundAttachment: 'fixed',
            backgroundSize: 'cover',
            backgroundRepeat: 'no-repeat',
            minHeight: '100vh',
        }}>
            <Navbar />
            <div className='container mt-5'>
                <div className="row">
                    {renderUsers()}
                    {renderProducts()}
                </div>
            </div>
        </div>
    );
}

export default AdminPage;