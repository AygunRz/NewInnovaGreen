import React, { useState } from 'react';
import { useMutation, gql } from '@apollo/client';
import Navbar from "../components/Navbar";
import { useNavigate, Link } from "react-router-dom";

const LOGIN_MUTATION = gql`
    mutation Login($email: String!, $password: String!) {
        login(email: $email, password: $password) {
            ok
            authToken
            role
            message
        }
    }
`;

export default function Login() {
    const [credentials, setCredentials] = useState({ email: "", password: "" });

    const [login, { data, loading, error }] = useMutation(LOGIN_MUTATION);

        let navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await login({ variables: { email: credentials.email, password: credentials.password } });

            if (response.data.login.ok) {
                console.log(response)
                localStorage.setItem('userEmail', credentials.email);
                localStorage.setItem('token', response.data.login.authToken);

                const userRole = response.data.login.role;
                localStorage.setItem('userRole', userRole); // Store user role

                if (userRole === 'Kunde') {
                    navigate("/"); // Redirect to home for Kunde
                } else if (userRole === 'Lieferant') {
                    navigate("/newfood")
                } else if (userRole === 'Admin') {
                    navigate("/adminPage")
                } else {
                    alert("Enter Valid Credentials");
                }
            } else {
                alert("Enter Valid Credentials");
            }
        } catch (e) {
            console.error('Error during login:', e);
            alert('Login failed.');
        }
    };

    const onChange = (e) => {
        setCredentials({ ...credentials, [e.target.name]: e.target.value });
    };

    return (
        <div style={{
            backgroundImage: 'url("https://images.pexels.com/photos/326278/pexels-photo-326278.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")',
            height: '100vh',
            backgroundSize: 'cover'
        }}>
            <div>
                <Navbar/>
            </div>
            <div className='container'>
                <form className='w-50 m-auto mt-5 border bg-dark border-success rounded' onSubmit={handleSubmit}>
                    <div className="m-3 text-light">
                        <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
                        <input type="email" className="form-control" name='email' value={credentials.email}
                               onChange={onChange} aria-describedby="emailHelp" required="true"/>
                        <div id="emailHelp" className="form-text">We'll never share your email with anyone.</div>
                    </div>
                    <div className="m-3 text-light">
                        <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
                        <input type="password" className="form-control" value={credentials.password} onChange={onChange}
                               name='password' required="true"/>
                    </div>
                    <button type="submit" className="m-3 btn btn-success">Submit</button>
                    <Link to="/signup" className="m-3 mx-1 btn btn-danger">New User</Link>
                </form>
            </div>
        </div>
    )
}
